
#include <iostream>
#include<stdio.h>
#include <conio.h>
#include<fstream>
#include<string>
#include<time.h>

using namespace std;

struct Entrada {
		int valor;
} entrada;

struct Entrada1 {
		int valor1;
} entrada1;
int a[1000000];
int n,aux,k;
string nombrearchivo;
string nombrearchivo1;
clock_t t_ini, t_fin;

void leer(){
    FILE *archivo1;
    string valorInt;

    printf("\n Teclea el nombre del archivo de entrada:   ");
	cin >> nombrearchivo;
	nombrearchivo+= ".txt";

	archivo1 = fopen(nombrearchivo.c_str(), "r");

	if(archivo1== NULL ){
		printf(" No se puede abrir el archivo ");
		exit(1);
	}
	else{
		printf(" Se abrio el archivo correctamente %s\n ", nombrearchivo.c_str() );
    }
    n=0;
    for (int i=0; !feof(archivo1); i++) {
        fscanf (archivo1, "%i", &entrada.valor);
        a[i]=entrada.valor;
        n++;
	}
	printf("valor de n es:  %i\n",n-1);
	fclose(archivo1);

}

void ordenar(){
    int flg1;
    cout<<"<-selecciona una opcion-->"<<endl;
    cout<<"<-(0)De menor a mayor"<<endl;
    cout<<"<-(1)De mayor a menor"<<endl;
    cout<<"<------------------------>"<<endl;
    cin>>flg1;
    if(flg1==0){
        for(int i=1;i<n;i++){
            for(int j=0;j<n-i;j++){
                if(a[j]>a[j+1]){
                    k=a[j+1]; a[j+1]=a[j]; a[j]=k;
                }
            }
        }
    }else if(flg1==1){
        for(int i=1;i<n;i++){
            for(int j=0;j<n-i;j++){
                if(a[j]<a[j+1]){
                    k=a[j+1]; a[j+1]=a[j]; a[j]=k;
                }
            }
        }
    }

}

void eliminar(){
    int flg2;
    cout<<"<-selecciona una opcion-->"<<endl;
    cout<<"<-(0)borrar duplicados"<<endl;
    cout<<"<-(1)borrar dijitos"<<endl;
    cout<<"<------------------------>"<<endl;
    cin>>flg2;
    if(flg2==0){
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                if(a[i]==a[j]){
                    for(int k=j;k<n;k++){
                        a[k]=a[k+1];
                        n=n-1;
                        j=i;
                    }
                }
            }
        }
    }else if(flg2==1){
        int pos,valor;
        cout<<"<-selecciona la posicion->"<<endl;
        cin>>pos;
        cout<<"<-introduce el valor del digito"<<endl;
        cin>>valor;
            if(a[pos]==valor){
                for(int k=pos;k<n;k++){
                    a[k]=a[k+1];
                    n=n-1;
                }
            }
    }
}
void mostrar(){
    cout<<"<------------------------>"<<endl;
    cout<<"<-impimir arreglo"<<endl;
    cout<<"<-impimir arreglo"<<endl;
    for(int i=0;i<n;i++){
        cout<<" ["<<a[i]<<"] "<<endl;
    }
}

int grabar(){
	FILE *archivo2;
    string valorInt;

    printf("\n Teclea el nombre del archivo de salida:   ");
	cin >> nombrearchivo1;
	nombrearchivo1+= ".txt";						 		// le agregarmos la extension ".txt"

	archivo2 = fopen(nombrearchivo1.c_str(), "w");		        // Abrimos archivo

	if(archivo2== NULL ){
		printf(" No se puede abrir el archivo ");
		exit(1);
	}
	else{
		printf(" Se abrio el archivo correctamente %s\n ", nombrearchivo1.c_str() );
    }
    aux=a[0];
    for (int i=0; i<=n; i++) {
        if (aux!=a[i]){
            entrada1.valor1=aux;
            aux=a[i];
            fprintf(archivo2, "%i\n", entrada1.valor1);
        }
    }
	printf("valor de n es:  %i\n",n-1);
	fclose(archivo2);
	return (0);
}

int main(){
    int flg,opt,cion;

    do{
        cout<<"BIENVENIDO A MI PROGRAMA "<<endl;
        cout<<"<------------------------>"<<endl;
        cout<<"<-(1)Leer"<<endl;
        cout<<"<-(2)Ordenar"<<endl;
        cout<<"<-(3)Eliminar"<<endl;
        cout<<"<-(4)Mostrar"<<endl;
        cout<<"<-(5)Grabar"<<endl;
        cout<<"<-(0)Cerrar"<<endl;
        cout<<"<------------------------>"<<endl;
        cout<<"<-selecciona una opcion-->"<<endl;
        cin>>opt;

        if(cion==1&&flg!=1){
            cout<<"la primer accion debe ser leer"<<endl;
            return 0;
        }
        switch(flg){
        case 1:
            leer();
            cion++;
            break;
        case 2:
            if(cion!=1&&flg!=5);
            ordenar();
            break;
        case 3:
            if(cion!=1&&flg!=5);
            eliminar();
            break;
        case 4:
            if(cion!=1&&flg!=5);
            eliminar();
            break;
        case 5:
            if(cion!=1);
            grabar();
            break;
        case 0:
            flg=0;
            return 0;
            break;
        default:
            cout<<"ingresa un valor valido"<<endl;
        }
    }while(flg!=0);
    return 0;
}










