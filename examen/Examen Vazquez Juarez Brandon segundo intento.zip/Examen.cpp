
#include <iostream>
#include<stdio.h>
#include <conio.h>
#include<fstream>
#include<string>
#include<time.h>

using namespace std;

struct Entrada {
		int valor;
} entrada;

struct Entrada1 {
		int valor1;
} entrada1;
int a[1000000];
int n,aux,k;
int izq;
int der;
int cn=0;
int salvacn=0;
string nombrearchivo;
string nombrearchivo1;
clock_t t_ini, t_fin;

void leer(){
    FILE *archivo1;
    string valorInt;

    printf("\n Teclea el nombre del archivo de entrada:   ");
	cin >> nombrearchivo;
	nombrearchivo+= ".txt";

	archivo1 = fopen(nombrearchivo.c_str(), "r");

	if(archivo1== NULL ){
		printf(" No se puede abrir el archivo ");
		exit(1);
	}
	else{
		printf(" Se abrio el archivo correctamente %s\n ", nombrearchivo.c_str() );
    }
    n=0;
    for (int i=0; !feof(archivo1); i++) {
        fscanf (archivo1, "%i", &entrada.valor);
        a[i]=entrada.valor;
        n++;
	}
	printf("valor de n es:  %i\n",n-1);
	fclose(archivo1);

}

void ordenar(){
    int flg1,i,j;
    cout<<"<-selecciona una opcion-->"<<endl;
    cout<<"<-(0)De mayor a menor"<<endl;
    cout<<"<-(1)De menor a mayor"<<endl;
    cout<<"<------------------------>"<<endl;
    cin>>flg1;
    if(flg1==1){

            int j;
        printf("Ordenamiento por insercion\n");
        cn=salvacn-1;
        for (i=0; i < n; i++) {
            k = a[i];                 // k es el indice
            j = i-1;
            while (j >= 0 && a[j] > k) {
                a[j + 1] = a[j];
                j--;
            }
            a[j+1] = k;
        }
    }if(flg1==0){
        for (i=0; i < n; i++) {
            k = a[i];
            j = i-1;
            while (j >= 0 && a[j] < k) {
                a[j + 1] = a[j];
                j--;
            }
            a[j+1] = k;
        }
    }
}

void eliminar(){
    int flg2;
    cout<<"<-selecciona una opcion-->"<<endl;
    cout<<"<-(0)borrar impares"<<endl;
    cout<<"<-(1)borrar menores"<<endl;
    cout<<"<-(2)digitos"<<endl;
    cout<<"<------------------------>"<<endl;
    cin>>flg2;
    if(flg2==0){
        cout<<"<-Eliminar impares-->"<<endl;
        for(int i=0;i<n;i++){
            if(a[i]%2 ==1){
                a[i]=a[i+1];
                for(int k=i+1;k<n;k++){
                    a[k]=a[k+1];
                    n=n-1;
                }
            }
        }
    }else if(flg2==1){
        int men;
        cout<<"<-Eliminar menores-->"<<endl;
        cout<<"<-introduce el valor minimo"<<endl;
        cin>>men;
         for(int i=0;i<n;i++){
            if(a[i]>men){
                a[i]=a[i+1];
                for(int k=i+1;k<n;k++){
                    a[k]=a[k+1];
                    n=n-1;
                }
            }
        }
    }else if(flg2==2){
        int pos,valor,arreglo[9]={0}, i=0, divisor=100000000, digito=0, sustraendo=0,num;
        cout<<"<-Eliminar el valor si esta el digito-->"<<endl;
        cout<<"<-selecciona la posicion->"<<endl;
        cin>>pos;
        cout<<"<-introduce el valor del digito"<<endl;
        cin>>valor;

        pos--;
        pos = 8-pos;
        for(int i = 0; i<n; i++){
            num = a[i];
            int div = 100000000;
                for(int j = 0;j<9; j++){
                    arreglo[j]= num / div;
                    num = num - (arreglo[j] * div);
                    div = div / 10;
        }
        if(arreglo[pos] == valor){
            for(int j=i; j<n; j++){
                a[j] = a[j+1];
                a[n] = 0;
                n--;
                if(arreglo[pos] == valor){
                    i--;
                }
            }
            }
        }
    }
}
void mostrar(){
    cout<<"<------------------------>"<<endl;
    cout<<"<-impimir arreglo"<<endl;
    for(int i=0;i<n;i++){
        cout<<" ["<<a[i]<<"] "<<endl;
    }
}

int grabar(){
	FILE *archivo2;
    string valorInt;

    printf("\n Teclea el nombre del archivo de salida:   ");
	cin >> nombrearchivo1;
	nombrearchivo1+= ".txt";						 		// le agregarmos la extension ".txt"

	archivo2 = fopen(nombrearchivo1.c_str(), "w");		        // Abrimos archivo

	if(archivo2== NULL ){
		printf(" No se puede abrir el archivo ");
		exit(1);
	}
	else{
		printf(" Se abrio el archivo correctamente %s\n ", nombrearchivo1.c_str() );
    }
    aux=a[0];
    for (int i=0; i<=n; i++) {
        if (aux!=a[i]){
            entrada1.valor1=aux;
            aux=a[i];
            fprintf(archivo2, "%i\n", entrada1.valor1);
        }
    }
	printf("valor de n es:  %i\n",n-1);
	fclose(archivo2);
	return (0);
}

int main(){
    int flg,opt,cion=0;
    cout<<"Brandon Vazquez Juarez "<<endl;
    cout<<"Examen "<<endl;
    do{
        cout<<"BIENVENIDO A MI PROGRAMA "<<endl;
        cout<<"<------------------------>"<<endl;
        cout<<"<-(1)Leer"<<endl;
        cout<<"<-(2)Ordenar"<<endl;
        cout<<"<-(3)Eliminar"<<endl;
        cout<<"<-(4)Mostrar"<<endl;
        cout<<"<-(5)Grabar"<<endl;
        cout<<"<-(0)Cerrar"<<endl;
        cout<<"<------------------------>"<<endl;
        cout<<"<-selecciona una opcion-->"<<endl;
        cin>>flg;
        system("cls");

        if(cion==0){
            cout<<"la primer accion debe ser leer"<<endl;
        }
        switch(flg){
        case 1:
            leer();
            cion++;
            break;
        case 2:
            if(cion!=0&&flg!=5){
                ordenar();
                system("cls");
            }
            break;
        case 3:
            if(cion!=0&&flg!=5){
                eliminar();
                system("cls");
            }
            break;
        case 4:
            if(cion!=0&&flg!=5){
                mostrar();
            }
            break;
        case 5:
            if(cion!=0);
            grabar();
            return 0;
            break;
        default:
            cout<<"ingresa un valor valido"<<endl;
        }
    }while(flg!=0);
    return 0;
}










